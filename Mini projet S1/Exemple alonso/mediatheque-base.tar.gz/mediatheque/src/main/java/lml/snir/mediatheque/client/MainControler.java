package lml.snir.mediatheque.client;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;

/**
 *
 * @author fanou
 */
public class MainControler implements Initializable {

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // to do init here
    }
    
    @FXML
    public void onMenuFileQuitClick() {
        System.out.println("quit");
        Platform.exit();
    }
    
}
