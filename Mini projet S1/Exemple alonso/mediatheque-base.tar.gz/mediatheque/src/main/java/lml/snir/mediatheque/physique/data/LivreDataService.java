package lml.snir.mediatheque.physique.data;

import java.util.List;
import lml.snir.mediatheque.metier.entity.Livre;

/**
 *
 * @author fanou
 */
public interface LivreDataService {
    public List<Livre> getByAuteur(String auteur) throws Exception;
    public List<Livre> getByTitre(String titre) throws Exception;
    public List<Livre> getByTitreEtDispo(String titre, boolean disponible) throws Exception;
}
