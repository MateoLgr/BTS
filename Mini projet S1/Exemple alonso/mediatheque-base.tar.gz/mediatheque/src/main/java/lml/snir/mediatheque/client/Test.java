package lml.snir.mediatheque.client;

import java.util.List;
import lml.snir.mediatheque.metier.MetierFactory;
import lml.snir.mediatheque.metier.entity.Adherent;
import lml.snir.mediatheque.metier.entity.Bibliothecaire;
import lml.snir.mediatheque.metier.transactionnel.AdherentService;
import lml.snir.mediatheque.physique.data.AdherentDataService;
import lml.snir.mediatheque.physique.data.PhysiqueDataFactory;

/**
 *
 * @author fanou
 */
public class Test {
    public static void main(String[] args) throws Exception {
        // ICI les tests de bases !
        Test test = new Test();
        
        test.testAdherentService();
    }
    
    private void testAdherentDataService() throws Exception {
        AdherentDataService adherentDataService = PhysiqueDataFactory.getAdherentDataService();
        List<Adherent> adherents = adherentDataService.getAll();
        for (Adherent a : adherents) {
            System.out.println(a);
        }
    }
    
    private void testAdherentService() throws Exception {
        AdherentService adherentService = MetierFactory.getAdherentService();
        List<Adherent> adherents = adherentService.getAll();
        for (Adherent a : adherents) {
            System.out.println(a);
        }
        System.out.println(adherentService.getBibliothecaireCount());
        System.out.println(adherentService.getByLogin("admin"));
        
        Bibliothecaire b = new Bibliothecaire("admin", "admin", "admin", true, "admin");
        adherentService.add(b);
        b = null;
        
        System.out.println(adherentService.getBibliothecaireCount());
        System.out.println(adherentService.getByLogin("admin"));
    }
}
