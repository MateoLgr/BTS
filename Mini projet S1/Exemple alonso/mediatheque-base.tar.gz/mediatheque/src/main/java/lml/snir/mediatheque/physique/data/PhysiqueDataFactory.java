package lml.snir.mediatheque.physique.data;


/**
 *
 * @author fanou
 */
public class PhysiqueDataFactory {

    private PhysiqueDataFactory() {
    }
    
    private static AdherentDataService adherentDataSrv = null;
   public static  AdherentDataService getAdherentDataService() throws Exception {
       if (adherentDataSrv == null) {
           adherentDataSrv = new AdherentDataServiceJDBCImpl();
       }
       return adherentDataSrv;
   }
}
